from task3 import ExamControl

ec = ExamControl();

a = ec.get_laser_readings();
print(a)

ec.main();